export const  firebaseConfig = {
    apiKey: "AIzaSyAeqpiOdV1UU3yjKn-fMuB8bZWeQc7Ke3U",
    authDomain: "controle-patrimonial-14860.firebaseapp.com",
    databaseURL: "https://controle-patrimonial-14860.firebaseio.com",
    projectId: "controle-patrimonial-14860",
    storageBucket: "controle-patrimonial-14860.appspot.com",
    messagingSenderId: "1046060836383",
    appId: "1:1046060836383:web:a1705dfe4b8958916e172a",
    measurementId: "G-Q7OZNQ5N5H"
  };